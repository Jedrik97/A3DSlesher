public struct EnemyDiedSignal
{
    public float Xp;

    public EnemyDiedSignal(float xp)
    {
        Xp = xp;
    }
}