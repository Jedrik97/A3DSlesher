public interface IDamageReceiver
{
    void ReceiveDamage(float amount, object source);
}